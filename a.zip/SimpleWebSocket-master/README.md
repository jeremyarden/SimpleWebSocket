# SimpleWebSocket
Simple WebSocket server implemented using Python 3

Kelompok HidupMahasiswa


Muhammad Rafi Zhafran 13517005

Abiyyu Avicenna Ismunandar 13517083

Jeremy Arden Hartono 13517101

## How to use
